# Aegis Cloud IEEE Paper Source

What the directory includes is the IEEE A4 conference-paper source for Aegis Cloud, including Agentic AI for Intelligent Cloud Resource Allocation and Autoscaling, to a significant degree.

Gather from this directory with a standard TeX distribution that includes `IEEEtran`, TikZ, and BibTeX:

```text
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

The paper intentionally outlines Aegis Cloud as a live predictive-autoscaling testbed with copied replica actuation. It doesn't claim rollout to Docker, Kubernetes, or a public-cloud control plane, in actual application.
