# Aegis Cloud IEEE Paper Source

This directory contains the IEEE A4 conference-paper source for Aegis Cloud: Agentic AI for Intelligent Cloud Resource Allocation and Autoscaling.

Compile from this directory with a standard TeX distribution that includes `IEEEtran`, TikZ, and BibTeX:

```text
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

The paper intentionally describes Aegis Cloud as a live predictive-autoscaling testbed with simulated replica actuation. It does not claim deployment to Docker, Kubernetes, or a public-cloud control plane.
